﻿using System;
using System.Collections.Generic;
 using System.Globalization;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;

 

using System.Data;
using System.Data.SqlClient;


public partial class _Default1 : System.Web.UI.Page
{
 
    protected void Page_Load(object sender, EventArgs e)
    {
   

             //  SqlConnection sqlbaglanti = new SqlConnection(@"Data Source=174.142.4.132; Initial Catalog=Kimiahost_d20; User ID=demah; Password=12345");

               // or

                SqlConnection sqlbaglanti = new SqlConnection(@"Data Source=(local); Initial Catalog=Kimiahost_d20; User ID=demah; Password=12345");

                sqlbaglanti.Open();

                Response.Write("OK");

                sqlbaglanti.Close();

           

/*
PersianCalendar pc= new PersianCalendar();
DateTime dt = DateTime.Now;
Response.Write( pc.GetYear(dt).ToString() + "/" + pc.GetMonth(dt).ToString() + "/" + pc.GetDayOfMonth(dt).ToString()+"  "+DateTime.Now.ToLongTimeString()+GetUsersIP());
*/

    }

public static string GetUsersIP()
		{
			System.Web.HttpContext current = System.Web.HttpContext.Current;
			string ipAddress = null;

			if ( current.Request.ServerVariables["HTTP_CLIENT_IP"] != null)
				ipAddress = current.Request.ServerVariables["HTTP_CLIENT_IP"];

			if ( ipAddress == null || ipAddress.Length == 0 || ipAddress == "unknown")
				if ( current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                    ipAddress = current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

			if ( ipAddress == null || ipAddress.Length == 0 || ipAddress == "unknown")
				if ( current.Request.ServerVariables["REMOTE_ADDR"] != null)
                    ipAddress = current.Request.ServerVariables["REMOTE_ADDR"];

			if ( ipAddress == null || ipAddress.Length == 0)
				ipAddress = "unknown";

			return ipAddress;
		}


  protected void Button1_Click(object sender, EventArgs e)
    {

Response.Write("rryrer");


  float fileSize = profilPic.PostedFile.ContentLength;
        float floatConverttoKB = fileSize / 1024;
        float floatConverttoMB = floatConverttoKB / 1024;
        string DirName = "images";
        string savepath = Server.MapPath(DirName + "/");
        DirectoryInfo dir = new DirectoryInfo(savepath);
        //   string savepath = "C:\\Documents and Settings\\ssis3\\My Documents\\Visual Studio 2005\\WebSites\\finalbookgroups\\" + DirName + "\\";
        if (fileSize < 4194304)
        {

            string filename = Server.HtmlEncode(profilPic.FileName);
            string extension = System.IO.Path.GetExtension(filename).ToUpper();
            if (extension.Equals(".jpg") || extension.Equals(".JPG") || extension.Equals(".JPEG") || extension.Equals(".GIF"))
            {

                savepath += filename;

                profilPic.SaveAs(savepath);
            }
        }







 

    }


}
